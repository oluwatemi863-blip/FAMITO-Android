package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// FAMITO Bright Modern Color Palette
val FamitoBrandPrimary = Color(0xFF0866FF)      // Vibrant Social Blue
val FamitoBrandPrimaryLight = Color(0xFFE7F3FF) // Soft Blue Tint Background
val FamitoBrandSecondary = Color(0xFF4285F4)    // Accent Blue
val FamitoBrandAccent = Color(0xFFE41E3F)       // Red Badge Alert Accent

val FamitoBgLight = Color(0xFFF0F2F5)           // Authentic Social Light Gray Background
val FamitoSurfaceLight = Color(0xFFFFFFFF)      // Pure White Surface
val FamitoSurfaceVariant = Color(0xFFE4E6EB)    // Icon/Pill Component Surface
val FamitoBorderLight = Color(0xFFCED0D4)       // Subtle Light Border

val FamitoTextPrimary = Color(0xFF050505)       // High-Contrast Header/Primary Text
val FamitoTextSecondary = Color(0xFF65676B)     // Medium Gray Body Text
val FamitoTextMuted = Color(0xFF8A8D91)         // Light Gray Timestamp/Subtext

// Feature Accents for Menu Cards & Icons
val FamitoGreenSuccess = Color(0xFF45BD62)
val FamitoRedDanger = Color(0xFFF3425F)
val FamitoBlueInfo = Color(0xFF1877F2)
val FamitoOrangeWarning = Color(0xFFF7B928)
val FamitoPurpleAi = Color(0xFF8A2BE2)
val FamitoPinkReels = Color(0xFFF75270)


