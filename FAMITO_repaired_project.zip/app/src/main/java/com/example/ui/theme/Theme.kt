package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CleanLightColorScheme = lightColorScheme(
    primary = FamitoBrandPrimary,
    onPrimary = Color.White,
    secondary = FamitoBrandSecondary,
    onSecondary = Color.White,
    tertiary = FamitoBrandAccent,
    onTertiary = Color.White,
    background = FamitoBgLight,
    onBackground = FamitoTextPrimary,
    surface = FamitoSurfaceLight,
    onSurface = FamitoTextPrimary,
    surfaceVariant = FamitoSurfaceVariant,
    onSurfaceVariant = FamitoTextSecondary,
    outline = FamitoBorderLight
)

@Composable
fun FamitoTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CleanLightColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    FamitoTheme(content = content)
}


