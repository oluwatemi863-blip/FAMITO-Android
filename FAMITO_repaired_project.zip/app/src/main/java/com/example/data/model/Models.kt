package com.example.data.model

data class User(
    val id: String,
    val name: String,
    val username: String,
    val avatarUrl: String? = null,
    val bio: String = "",
    val followersCount: Int = 0,
    val followingCount: Int = 0,
    val postsCount: Int = 0,
    val isVerified: Boolean = false
)

data class Story(
    val id: String,
    val user: User,
    val isCreateCard: Boolean = false,
    val mediaUrl: String? = null,
    val isViewed: Boolean = false
)

data class Post(
    val id: String,
    val user: User,
    val timestamp: String,
    val privacy: String = "Public",
    val content: String,
    val imageUrl: String? = null,
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val sharesCount: Int = 0,
    val isLiked: Boolean = false,
    val isSaved: Boolean = false
)

data class NotificationItem(
    val id: String,
    val user: User,
    val text: String,
    val timestamp: String,
    val isRead: Boolean = false,
    val type: String = "LIKE" // LIKE, COMMENT, MENTION, FRIEND
)

data class MenuItem(
    val title: String,
    val category: String,
    val iconName: String
)
