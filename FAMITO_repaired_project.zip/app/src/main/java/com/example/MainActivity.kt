package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OndemandVideo
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Store
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbUpOffAlt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Message
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.OndemandVideo
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Store
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.NotificationItem
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.model.User
import com.example.ui.theme.FamitoBgLight
import com.example.ui.theme.FamitoBlueInfo
import com.example.ui.theme.FamitoBorderLight
import com.example.ui.theme.FamitoBrandAccent
import com.example.ui.theme.FamitoBrandPrimary
import com.example.ui.theme.FamitoBrandPrimaryLight
import com.example.ui.theme.FamitoBrandSecondary
import com.example.ui.theme.FamitoGreenSuccess
import com.example.ui.theme.FamitoOrangeWarning
import com.example.ui.theme.FamitoPinkReels
import com.example.ui.theme.FamitoPurpleAi
import com.example.ui.theme.FamitoRedDanger
import com.example.ui.theme.FamitoSurfaceLight
import com.example.ui.theme.FamitoSurfaceVariant
import com.example.ui.theme.FamitoTextMuted
import com.example.ui.theme.FamitoTextPrimary
import com.example.ui.theme.FamitoTextSecondary
import com.example.ui.theme.FamitoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FamitoTheme {
                FamitoAppMainScreen()
            }
        }
    }
}

enum class FamitoTab {
    HOME, DISCOVER, CREATE, NOTIFICATIONS, PROFILE, MENU
}

// Sample Data
val currentUser = User(
    id = "u1",
    name = "Rita Michael",
    username = "@rita_m",
    bio = "Living life with gratitude & purpose ✨ Exploring beauty in everyday moments.",
    followersCount = 15400,
    followingCount = 420,
    postsCount = 210,
    isVerified = true
)

val sampleUsers = listOf(
    User("u2", "Oma igbo", "@oma_igbo", isVerified = true),
    User("u3", "Samuel", "@samuel_k", isVerified = false),
    User("u4", "Oliver", "@comr_oliver", isVerified = true),
    User("u5", "Ojo Awol", "@ojo_awol", isVerified = false)
)

val initialStories = listOf(
    Story("s0", currentUser, isCreateCard = true),
    Story("s1", sampleUsers[1], mediaUrl = "1"),
    Story("s2", sampleUsers[2], mediaUrl = "2"),
    Story("s3", sampleUsers[3], mediaUrl = "1"),
    Story("s4", sampleUsers[0], mediaUrl = "2")
)

val initialPosts = listOf(
    Post(
        id = "p1",
        user = sampleUsers[0],
        timestamp = "1d",
        privacy = "Public",
        content = "😳 😳 #photography #photooftheday",
        likesCount = 3420,
        commentsCount = 184,
        sharesCount = 62,
        isLiked = true
    ),
    Post(
        id = "p2",
        user = currentUser,
        timestamp = "2h",
        privacy = "Public",
        content = "Grateful for quiet mornings and fresh beginnings! Wishing everyone a blessed and productive week ahead. ✨ 🙏 #mindfulness #positivity",
        likesCount = 1240,
        commentsCount = 48,
        sharesCount = 18,
        isLiked = false
    ),
    Post(
        id = "p3",
        user = sampleUsers[1],
        timestamp = "4h",
        privacy = "Public",
        content = "Our year of divine manifestation! 💯 Excited for what lies ahead with the team. #manifestation #faith #goals",
        likesCount = 890,
        commentsCount = 32,
        sharesCount = 12
    )
)

val sampleNotifications = listOf(
    NotificationItem("n1", sampleUsers[0], "liked your photo in photography circle.", "10m ago", isRead = false, type = "LIKE"),
    NotificationItem("n2", sampleUsers[1], "commented: 'Amen! Beautiful post.'", "1h ago", isRead = false, type = "COMMENT"),
    NotificationItem("n3", sampleUsers[2], "started following your updates.", "3h ago", isRead = true, type = "FRIEND"),
    NotificationItem("n4", sampleUsers[3], "mentioned you in a post.", "5h ago", isRead = true, type = "MENTION")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FamitoAppMainScreen() {
    var activeTab by remember { mutableStateOf(FamitoTab.HOME) }
    var showComposerDialog by remember { mutableStateOf(false) }
    var postsState by remember { mutableStateOf(initialPosts) }
    var notificationsState by remember { mutableStateOf(sampleNotifications) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = FamitoBgLight,
        topBar = {
            FamitoHeaderBar(
                activeTab = activeTab,
                onTabSelect = { tab -> activeTab = tab },
                onMenuClick = { activeTab = FamitoTab.MENU }
            )
        },
        bottomBar = {
            FamitoBottomNavBar(
                activeTab = activeTab,
                onTabSelect = { tab ->
                    if (tab == FamitoTab.CREATE) {
                        showComposerDialog = true
                    } else {
                        activeTab = tab
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                FamitoTab.HOME -> HomeScreenView(
                    posts = postsState,
                    onOpenComposer = { showComposerDialog = true },
                    onLikeClick = { post ->
                        postsState = postsState.map {
                            if (it.id == post.id) {
                                val newLiked = !it.isLiked
                                it.copy(
                                    isLiked = newLiked,
                                    likesCount = if (newLiked) it.likesCount + 1 else it.likesCount - 1
                                )
                            } else it
                        }
                    },
                    onSaveClick = { post ->
                        postsState = postsState.map {
                            if (it.id == post.id) it.copy(isSaved = !it.isSaved) else it
                        }
                    }
                )
                FamitoTab.DISCOVER -> DiscoverScreenView(
                    onUserClick = { activeTab = FamitoTab.PROFILE }
                )
                FamitoTab.NOTIFICATIONS -> NotificationsScreenView(
                    notifications = notificationsState,
                    onMarkAllRead = {
                        notificationsState = notificationsState.map { it.copy(isRead = true) }
                    }
                )
                FamitoTab.PROFILE -> ProfileScreenView(
                    user = currentUser,
                    posts = postsState.filter { it.user.id == currentUser.id },
                    onLikeClick = { post ->
                        postsState = postsState.map {
                            if (it.id == post.id) {
                                val newLiked = !it.isLiked
                                it.copy(
                                    isLiked = newLiked,
                                    likesCount = if (newLiked) it.likesCount + 1 else it.likesCount - 1
                                )
                            } else it
                        }
                    }
                )
                FamitoTab.MENU -> MenuScreenView(
                    user = currentUser,
                    onProfileClick = { activeTab = FamitoTab.PROFILE },
                    onNavigateToTab = { tab -> activeTab = tab }
                )
                FamitoTab.CREATE -> HomeScreenView(
                    posts = postsState,
                    onOpenComposer = { showComposerDialog = true },
                    onLikeClick = {},
                    onSaveClick = {}
                )
            }
        }

        if (showComposerDialog) {
            PostComposerDialog(
                user = currentUser,
                onDismiss = { showComposerDialog = false },
                onPostCreated = { text ->
                    val newPost = Post(
                        id = "p_${System.currentTimeMillis()}",
                        user = currentUser,
                        timestamp = "Just now",
                        privacy = "Public",
                        content = text,
                        likesCount = 0,
                        commentsCount = 0,
                        sharesCount = 0
                    )
                    postsState = listOf(newPost) + postsState
                    showComposerDialog = false
                    activeTab = FamitoTab.HOME
                }
            )
        }
    }
}

// ==========================================
// HEADER BAR WITH BRAND + TOP TABS WITH RED BADGES
// ==========================================
@Composable
fun FamitoHeaderBar(
    activeTab: FamitoTab,
    onTabSelect: (FamitoTab) -> Unit,
    onMenuClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = FamitoSurfaceLight,
        shadowElevation = 1.dp
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Row 1: Brand Title on Left, Top Right Action Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Lowercase/Title "famito" Brand Title
                Text(
                    text = "famito",
                    fontSize = 28.sp,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.Bold,
                    color = FamitoBrandPrimary,
                    letterSpacing = (-0.5).sp,
                    modifier = Modifier.clickable { onTabSelect(FamitoTab.HOME) }
                )

                // Top Action Buttons (Search, Notifications, Menu)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TopHeaderCircleButton(
                        icon = Icons.Default.Search,
                        contentDescription = "Search",
                        onClick = { onTabSelect(FamitoTab.DISCOVER) }
                    )
                    TopHeaderCircleButton(
                        icon = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        onClick = { onTabSelect(FamitoTab.NOTIFICATIONS) }
                    )
                    TopHeaderCircleButton(
                        icon = Icons.Default.Menu,
                        contentDescription = "Menu",
                        onClick = onMenuClick
                    )
                }
            }

            // Row 2: Secondary Navigation Tabs Bar with Red Notification Badges
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TabIconWithBadge(
                    icon = if (activeTab == FamitoTab.HOME) Icons.Default.Home else Icons.Outlined.Home,
                    badgeText = "15+",
                    isSelected = activeTab == FamitoTab.HOME,
                    onClick = { onTabSelect(FamitoTab.HOME) }
                )
                TabIconWithBadge(
                    icon = Icons.Outlined.People,
                    badgeText = "3",
                    isSelected = false,
                    onClick = { onTabSelect(FamitoTab.DISCOVER) }
                )
                TabIconWithBadge(
                    icon = Icons.Outlined.Message,
                    badgeText = null,
                    isSelected = false,
                    onClick = { onTabSelect(FamitoTab.NOTIFICATIONS) }
                )
                TabIconWithBadge(
                    icon = Icons.Outlined.OndemandVideo,
                    badgeText = "15+",
                    isSelected = false,
                    onClick = { onTabSelect(FamitoTab.DISCOVER) }
                )
                TabIconWithBadge(
                    icon = if (activeTab == FamitoTab.NOTIFICATIONS) Icons.Default.Notifications else Icons.Outlined.Notifications,
                    badgeText = "15+",
                    isSelected = activeTab == FamitoTab.NOTIFICATIONS,
                    onClick = { onTabSelect(FamitoTab.NOTIFICATIONS) }
                )
                TabIconWithBadge(
                    icon = if (activeTab == FamitoTab.MENU) Icons.Default.Store else Icons.Outlined.Store,
                    badgeText = null,
                    isSelected = activeTab == FamitoTab.MENU,
                    onClick = onMenuClick
                )
            }
        }
    }
}

@Composable
fun TopHeaderCircleButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(FamitoSurfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = FamitoTextPrimary,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun RowScope.TabIconWithBadge(
    icon: ImageVector,
    badgeText: String?,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .clickable { onClick() }
            .padding(vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) FamitoBrandPrimary else FamitoTextSecondary,
                    modifier = Modifier.size(26.dp)
                )

                if (badgeText != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(start = 14.dp, bottom = 12.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(FamitoBrandAccent)
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Active Tab Indicator Blue Line
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .width(40.dp)
                        .height(3.dp)
                        .background(FamitoBrandPrimary, RoundedCornerShape(2.dp))
                )
            } else {
                Spacer(modifier = Modifier.height(3.dp))
            }
        }
    }
}

// ==========================================
// HOME SCREEN VIEW
// ==========================================
@Composable
fun HomeScreenView(
    posts: List<Post>,
    onOpenComposer: () -> Unit,
    onLikeClick: (Post) -> Unit,
    onSaveClick: (Post) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // 3. Stories Carousel
        item {
            StoriesSection()
        }

        // 4. Post Composer ("What's on your mind?")
        item {
            PostComposerEntryCard(user = currentUser, onClick = onOpenComposer)
        }

        // 5. Feed Posts
        items(posts, key = { it.id }) { post ->
            PostCardView(
                post = post,
                onLikeClick = { onLikeClick(post) },
                onSaveClick = { onSaveClick(post) }
            )
        }
    }
}

// ==========================================
// POST COMPOSER ENTRY CARD
// ==========================================
@Composable
fun PostComposerEntryCard(user: User, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = FamitoSurfaceLight
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // User Profile Avatar with Green Online Dot
                Box(modifier = Modifier.size(42.dp)) {
                    UserAvatarBox(name = user.name, size = 42.dp)
                    // Green Online Dot
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(FamitoGreenSuccess)
                            .border(2.dp, FamitoSurfaceLight, CircleShape)
                            .align(Alignment.BottomEnd)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                // Rounded Input Box "What's on your mind?"
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(FamitoBgLight)
                        .clickable { onClick() }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "What's on your mind?",
                        color = FamitoTextSecondary,
                        fontSize = 15.sp
                    )
                }
            }

            Divider(color = FamitoBorderLight, thickness = 0.5.dp)

            // Photo & Video Options Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onClick() }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = "Photo",
                        tint = FamitoGreenSuccess,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Photo",
                        fontSize = 13.sp,
                        color = FamitoTextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Box(
                    modifier = Modifier
                        .width(1.dp)
                        .height(16.dp)
                        .background(FamitoBorderLight)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onClick() }
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Video",
                        tint = FamitoRedDanger,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Video",
                        fontSize = 13.sp,
                        color = FamitoTextSecondary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

// ==========================================
// STORIES SECTION (CAROUSEL MATCHING SCREENSHOT)
// ==========================================
@Composable
fun StoriesSection() {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = FamitoSurfaceLight
    ) {
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(initialStories) { story ->
                if (story.isCreateCard) {
                    CreateStoryCard(user = story.user)
                } else {
                    UserStoryCard(story = story)
                }
            }
        }
    }
}

@Composable
fun CreateStoryCard(user: User) {
    Card(
        modifier = Modifier
            .width(108.dp)
            .height(178.dp)
            .clickable { },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = FamitoSurfaceVariant),
        border = BorderStroke(1.dp, FamitoBorderLight)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Top 65%: User Image / Gradient Background
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.65f)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(FamitoBrandPrimaryLight, FamitoBrandPrimary.copy(alpha = 0.4f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    UserAvatarBox(name = user.name, size = 48.dp)
                }

                // Bottom 35%: White Card with Text
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.35f)
                        .background(FamitoSurfaceLight),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Text(
                        text = "Create story",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = FamitoTextPrimary,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }

            // Circular Blue + Icon at exact middle seam
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(FamitoBrandPrimary)
                    .border(2.dp, FamitoSurfaceLight, CircleShape)
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create story",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
fun UserStoryCard(story: Story) {
    Card(
        modifier = Modifier
            .width(108.dp)
            .height(178.dp)
            .clickable { },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = FamitoSurfaceVariant),
        border = BorderStroke(0.5.dp, FamitoBorderLight)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Background visual gradient preview
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                FamitoBrandPrimary.copy(alpha = 0.35f),
                                FamitoBrandSecondary.copy(alpha = 0.5f),
                                Color.Black.copy(alpha = 0.8f)
                            )
                        )
                    )
            )

            // Profile Picture with Blue Story Ring at Top Left
            Box(
                modifier = Modifier
                    .padding(8.dp)
                    .align(Alignment.TopStart)
                    .size(36.dp)
                    .clip(CircleShape)
                    .border(2.dp, FamitoBrandPrimary, CircleShape)
                    .padding(2.dp)
            ) {
                UserAvatarBox(name = story.user.name, size = 32.dp)
            }

            // User Name Overlay at Bottom
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(8.dp)
            ) {
                Text(
                    text = story.user.name,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ==========================================
// POST CARD VIEW (MATCHING COLLAGE & FEED UI)
// ==========================================
@Composable
fun PostCardView(
    post: Post,
    onLikeClick: () -> Unit,
    onSaveClick: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = FamitoSurfaceLight
    ) {
        Column(modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)) {
            // Post Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Profile Avatar with Blue Story Ring
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .border(2.dp, FamitoBrandPrimary, CircleShape)
                            .padding(2.dp)
                    ) {
                        UserAvatarBox(name = post.user.name, size = 38.dp)
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = post.user.name,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = FamitoTextPrimary
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${post.timestamp} • ",
                                fontSize = 12.sp,
                                color = FamitoTextMuted
                            )
                            Icon(
                                imageVector = Icons.Default.Public,
                                contentDescription = "Public",
                                tint = FamitoTextMuted,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = { }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.MoreHoriz,
                            contentDescription = "Options",
                            tint = FamitoTextSecondary
                        )
                    }
                    IconButton(onClick = { }, modifier = Modifier.size(32.dp)) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss",
                            tint = FamitoTextSecondary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Post Text Content with Blue Hashtags
            val annotatedContent = buildAnnotatedString {
                val words = post.content.split(" ")
                words.forEachIndexed { index, word ->
                    if (word.startsWith("#")) {
                        withStyle(style = SpanStyle(color = FamitoBrandPrimary, fontWeight = FontWeight.Bold)) {
                            append(word)
                        }
                    } else {
                        append(word)
                    }
                    if (index < words.size - 1) append(" ")
                }
            }

            Text(
                text = annotatedContent,
                fontSize = 15.sp,
                color = FamitoTextPrimary,
                modifier = Modifier.padding(horizontal = 12.dp),
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Post Photo Collage Grid (Matching Screenshot)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Left Image
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(FamitoSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            tint = FamitoBrandPrimary,
                            modifier = Modifier.size(36.dp)
                        )
                        Text("Photo 1", fontSize = 12.sp, color = FamitoTextMuted)
                    }
                }

                // Right Image
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxSize()
                        .background(FamitoSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Image,
                            contentDescription = null,
                            tint = FamitoBrandSecondary,
                            modifier = Modifier.size(36.dp)
                        )
                        Text("Photo 2", fontSize = 12.sp, color = FamitoTextMuted)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Reaction Stats & Counters
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(FamitoBrandPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ThumbUp,
                            contentDescription = "Likes",
                            tint = Color.White,
                            modifier = Modifier.size(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${post.likesCount}",
                        fontSize = 12.sp,
                        color = FamitoTextSecondary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${post.commentsCount} comments", fontSize = 12.sp, color = FamitoTextSecondary)
                    Text("•", fontSize = 12.sp, color = FamitoTextMuted)
                    Text("${post.sharesCount} shares", fontSize = 12.sp, color = FamitoTextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = FamitoBorderLight, thickness = 0.5.dp)

            // Action Buttons Bar (Like, Comment, Share, Save)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onLikeClick() }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = if (post.isLiked) Icons.Default.ThumbUp else Icons.Default.ThumbUpOffAlt,
                        contentDescription = "Like",
                        tint = if (post.isLiked) FamitoBrandPrimary else FamitoTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Like",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (post.isLiked) FamitoBrandPrimary else FamitoTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = FamitoTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Comment",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = FamitoTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = FamitoTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Share",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = FamitoTextSecondary
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onSaveClick() }
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = if (post.isSaved) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                        contentDescription = "Save",
                        tint = if (post.isSaved) FamitoBrandPrimary else FamitoTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (post.isSaved) "Saved" else "Save",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (post.isSaved) FamitoBrandPrimary else FamitoTextSecondary
                    )
                }
            }
        }
    }
}

// ==========================================
// MENU SCREEN (MATCHING SCREENSHOT_20260813-063401)
// ==========================================
@Composable
fun MenuScreenView(
    user: User,
    onProfileClick: () -> Unit,
    onNavigateToTab: (FamitoTab) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FamitoBgLight),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onNavigateToTab(FamitoTab.HOME) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = FamitoTextPrimary)
                    }
                    Text(
                        text = "Menu",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = FamitoTextPrimary
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TopHeaderCircleButton(
                        icon = Icons.Default.SwapVert,
                        contentDescription = "Switch",
                        onClick = { }
                    )
                    TopHeaderCircleButton(
                        icon = Icons.Default.Search,
                        contentDescription = "Search",
                        onClick = { onNavigateToTab(FamitoTab.DISCOVER) }
                    )
                }
            }
        }

        // Profile Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onProfileClick() },
                color = FamitoSurfaceLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.8.dp, FamitoBorderLight)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatarBox(name = user.name, size = 44.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(user.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FamitoTextPrimary)
                            Text("View your profile", fontSize = 12.sp, color = FamitoTextMuted)
                        }
                    }
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(FamitoSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Dropdown", tint = FamitoTextPrimary)
                    }
                }
            }
        }

        // Switch Account Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { },
                color = FamitoSurfaceLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.8.dp, FamitoBorderLight)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        UserAvatarBox(name = sampleUsers[0].name, size = 36.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Switch account", fontWeight = FontWeight.Medium, fontSize = 15.sp, color = FamitoTextPrimary)
                    }
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(FamitoSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Dropdown", tint = FamitoTextPrimary)
                    }
                }
            }
        }

        // Invite Friends Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { },
                color = FamitoSurfaceLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.8.dp, FamitoBorderLight)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Invite",
                        tint = FamitoRedDanger,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text("Invite friends", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = FamitoTextPrimary)
                }
            }
        }

        // 2-Column Menu Grid (Matching Screenshot)
        item {
            val menuItems = listOf(
                MenuGridEntry("Messages", Icons.Default.Message, FamitoPurpleAi),
                MenuGridEntry("Groups", Icons.Default.Group, FamitoBrandPrimary),
                MenuGridEntry("Friends", Icons.Default.People, FamitoBlueInfo),
                MenuGridEntry("Reels", Icons.Default.Videocam, FamitoPinkReels),
                MenuGridEntry("Marketplace", Icons.Default.Store, FamitoBrandPrimary),
                MenuGridEntry("FAMITO AI", Icons.Default.AutoAwesome, FamitoPurpleAi),
                MenuGridEntry("Pages", Icons.Default.Flag, FamitoOrangeWarning),
                MenuGridEntry("Saved", Icons.Default.Bookmark, FamitoPurpleAi),
                MenuGridEntry("Memories", Icons.Default.History, FamitoBlueInfo),
                MenuGridEntry("Birthdays", Icons.Default.Cake, FamitoPinkReels),
                MenuGridEntry("Events", Icons.Default.Event, FamitoRedDanger),
                MenuGridEntry("FAMITO Verified", Icons.Default.Verified, FamitoBrandPrimary)
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                menuItems.chunked(2).forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        rowItems.forEach { item ->
                            Surface(
                                color = FamitoSurfaceLight,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(0.8.dp, FamitoBorderLight),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { }
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = item.title,
                                        tint = item.color,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Text(
                                        text = item.title,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = FamitoTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Expandable Settings & Privacy
        item {
            MenuExpandableItem(title = "Settings & Privacy", icon = Icons.Default.Settings)
        }
        item {
            MenuExpandableItem(title = "Help & Support", icon = Icons.Default.HelpOutline)
        }
        item {
            MenuExpandableItem(title = "Log Out", icon = Icons.Default.Logout, textColor = FamitoRedDanger)
        }
    }
}

data class MenuGridEntry(val title: String, val icon: ImageVector, val color: Color)

@Composable
fun MenuExpandableItem(title: String, icon: ImageVector, textColor: Color = FamitoTextPrimary) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { },
        color = FamitoSurfaceLight,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(0.8.dp, FamitoBorderLight)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = title, tint = textColor, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = textColor)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = "Expand", tint = FamitoTextMuted)
        }
    }
}

// ==========================================
// BOTTOM NAVIGATION BAR
// ==========================================
@Composable
fun FamitoBottomNavBar(
    activeTab: FamitoTab,
    onTabSelect: (FamitoTab) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = FamitoSurfaceLight,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomNavItem(
                icon = if (activeTab == FamitoTab.HOME) Icons.Default.Home else Icons.Outlined.Home,
                label = "Home",
                isSelected = activeTab == FamitoTab.HOME,
                onClick = { onTabSelect(FamitoTab.HOME) }
            )
            BottomNavItem(
                icon = if (activeTab == FamitoTab.DISCOVER) Icons.Default.People else Icons.Outlined.People,
                label = "Discover",
                isSelected = activeTab == FamitoTab.DISCOVER,
                onClick = { onTabSelect(FamitoTab.DISCOVER) }
            )
            // Center Prominent Create Button
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(FamitoBrandPrimary)
                    .clickable { onTabSelect(FamitoTab.CREATE) },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create", tint = Color.White, modifier = Modifier.size(24.dp))
            }
            BottomNavItem(
                icon = if (activeTab == FamitoTab.NOTIFICATIONS) Icons.Default.Notifications else Icons.Outlined.Notifications,
                label = "Notifications",
                isSelected = activeTab == FamitoTab.NOTIFICATIONS,
                onClick = { onTabSelect(FamitoTab.NOTIFICATIONS) }
            )
            BottomNavItem(
                icon = if (activeTab == FamitoTab.PROFILE) Icons.Default.Person else Icons.Outlined.Person,
                label = "Profile",
                isSelected = activeTab == FamitoTab.PROFILE,
                onClick = { onTabSelect(FamitoTab.PROFILE) }
            )
        }
    }
}

@Composable
fun BottomNavItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) FamitoBrandPrimary else FamitoTextSecondary,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) FamitoBrandPrimary else FamitoTextSecondary
        )
    }
}

// ==========================================
// HELPER COMPONENTS (AVATAR, DISCOVER, PROFILE)
// ==========================================
@Composable
fun UserAvatarBox(name: String, size: androidx.compose.ui.unit.Dp) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(
                Brush.linearGradient(
                    colors = listOf(FamitoBrandPrimary, FamitoBrandSecondary)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name.take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.4).sp
        )
    }
}

@Composable
fun PostComposerDialog(
    user: User,
    onDismiss: () -> Unit,
    onPostCreated: (String) -> Unit
) {
    var textState by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = FamitoSurfaceLight
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Create Post", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserAvatarBox(name = user.name, size = 36.dp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(user.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = textState,
                    onValueChange = { textState = it },
                    placeholder = { Text("What's on your mind?") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (textState.isNotBlank()) {
                            onPostCreated(textState)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = FamitoBrandPrimary),
                    shape = RoundedCornerShape(20.dp),
                    enabled = textState.isNotBlank()
                ) {
                    Text("Post", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DiscoverScreenView(onUserClick: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Search FAMITO posts, people, hashtags...", color = FamitoTextMuted, fontSize = 14.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = FamitoBrandPrimary) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = FamitoSurfaceLight,
                    unfocusedContainerColor = FamitoSurfaceLight,
                    focusedBorderColor = FamitoBrandPrimary,
                    unfocusedBorderColor = FamitoBorderLight
                ),
                singleLine = true
            )
        }

        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = FamitoSurfaceLight,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(0.8.dp, FamitoBorderLight)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Suggested People", style = MaterialTheme.typography.titleMedium, color = FamitoTextPrimary)
                    Spacer(modifier = Modifier.height(12.dp))

                    sampleUsers.forEach { user ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp)
                                .clickable { onUserClick() },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                UserAvatarBox(name = user.name, size = 40.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(user.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = FamitoTextPrimary)
                                    Text(user.username, fontSize = 12.sp, color = FamitoTextMuted)
                                }
                            }
                            Button(
                                onClick = { },
                                colors = ButtonDefaults.buttonColors(containerColor = FamitoBrandPrimary),
                                shape = RoundedCornerShape(20.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = "Follow", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Follow", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationsScreenView(
    notifications: List<NotificationItem>,
    onMarkAllRead: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = FamitoSurfaceLight
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Notifications", style = MaterialTheme.typography.titleLarge, color = FamitoTextPrimary)
                Text(
                    text = "Mark all read",
                    fontSize = 13.sp,
                    color = FamitoBrandPrimary,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clickable { onMarkAllRead() }
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(notifications) { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    color = if (!item.isRead) FamitoBrandPrimaryLight else FamitoSurfaceLight,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        UserAvatarBox(name = item.user.name, size = 44.dp)
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                buildAnnotatedString {
                                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = FamitoTextPrimary)) {
                                        append(item.user.name)
                                    }
                                    append(" ")
                                    append(item.text)
                                },
                                fontSize = 13.sp,
                                color = FamitoTextSecondary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(item.timestamp, fontSize = 11.sp, color = FamitoTextMuted)
                        }
                        if (!item.isRead) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(FamitoBrandAccent)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreenView(
    user: User,
    posts: List<Post>,
    onLikeClick: (Post) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(FamitoBrandPrimary, FamitoBrandSecondary)
                            )
                        )
                )

                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp)
                        .size(88.dp)
                        .clip(CircleShape)
                        .border(3.dp, FamitoSurfaceLight, CircleShape)
                        .background(FamitoBrandPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = user.name.take(1),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }

        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(user.name, style = MaterialTheme.typography.titleLarge, color = FamitoTextPrimary)
                            if (user.isVerified) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = FamitoBrandPrimary, modifier = Modifier.size(18.dp))
                            }
                        }
                        Text(user.username, fontSize = 13.sp, color = FamitoTextMuted)
                    }

                    Button(
                        onClick = {},
                        colors = ButtonDefaults.buttonColors(containerColor = FamitoBrandPrimary),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text("Edit Profile", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(user.bio, fontSize = 13.sp, color = FamitoTextSecondary, lineHeight = 18.sp)
                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(FamitoSurfaceLight)
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    ProfileStatItem(count = "${user.postsCount}", label = "Posts")
                    ProfileStatItem(count = "${user.followersCount}", label = "Followers")
                    ProfileStatItem(count = "${user.followingCount}", label = "Following")
                }
            }
        }

        items(posts, key = { it.id }) { post ->
            PostCardView(
                post = post,
                onLikeClick = { onLikeClick(post) },
                onSaveClick = { }
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun ProfileStatItem(count: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(count, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = FamitoTextPrimary)
        Text(label, fontSize = 12.sp, color = FamitoTextMuted)
    }
}
